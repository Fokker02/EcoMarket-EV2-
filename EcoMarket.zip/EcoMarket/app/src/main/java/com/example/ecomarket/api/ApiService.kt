package com.example.ecomarket.api

interface ApiService {
}